package com.cybage.model;

import java.time.LocalDate;

public class Complain {
	private String compId;
	private String citizenId;
	private String deptId;
	private String description;
	private String status;
	private String remark;
	private String file;
	private LocalDate date;
	
	public Complain() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Complain(String compId, String citizenId, String deptId, String description, String status,
			String remark, String file, LocalDate date) {
		super();
		this.compId = compId;
		this.citizenId = citizenId;
		this.deptId = deptId;
		this.description = description;
		this.status = status;
		this.remark = remark;
		this.file = file;
		this.date = date;
	}
	
	
	public Complain(String compId, String description, String status, String file, LocalDate date) {
		super();
		this.compId = compId;
		this.description = description;
		this.status = status;
		this.file = file;
		this.date = date;
	}
	public String getCompId() {
		return compId;
	}
	public void setCompId(String compId) {
		this.compId = compId;
	}
	public String getCitizenId() {
		return citizenId;
	}
	public void setCitizenId(String citizenId) {
		this.citizenId = citizenId;
	}
	public String getDeptId() {
		return deptId;
	}
	public void setDeptId(String deptId) {
		this.deptId = deptId;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getFile() {
		return file;
	}
	public void setFile(String file) {
		this.file = file;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	@Override
	public String toString() {
		return "ComplainTable [compId=" + compId + ", citizenId=" + citizenId + ", deptId=" + deptId + ", description="
				+ description + ", status=" + status + ", remark=" + remark + ", file=" + file + ", date=" + date + "]";
	}
	
	

}
