package com.cybage.service;

import java.time.LocalDate;

import com.cybage.dao.CitizenDaoImpl;
import com.cybage.model.Complain;

public class CitizenServiceImpl implements iCitizenService {
	
	private String generateCompID(){
		return "C"+ Math.round(Math.random()*999999999);
	}
	CitizenDaoImpl cdao = new CitizenDaoImpl();
	
	@Override
	public int addComplain(Complain comp) throws Exception {
		LocalDate today = LocalDate.now();
		Complain compln = new Complain(generateCompID(), comp.getDescription(), comp.getStatus(), comp.getFile(), today);
		System.out.println("in service");
		cdao.addComplain(compln);
		return 0;
	}

}
