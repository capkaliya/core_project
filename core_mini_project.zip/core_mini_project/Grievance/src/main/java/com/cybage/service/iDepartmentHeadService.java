package com.cybage.service;

public interface iDepartmentHeadService {

}
