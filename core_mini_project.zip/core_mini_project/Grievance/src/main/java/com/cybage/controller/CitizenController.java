package com.cybage.controller;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import org.apache.catalina.core.ApplicationContext;

import com.cybage.model.Complain;
import com.cybage.service.CitizenServiceImpl;
import com.cybage.service.iCitizenService;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB
maxFileSize = 1024 * 1024 * 1000, // 1 GB
maxRequestSize = 1024 * 1024 * 1000)   	// 1 GB
public class CitizenController extends HttpServlet {
	iCitizenService complainSer = new CitizenServiceImpl() ;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String path = request.getPathInfo();
		System.out.println(path);
		if(path.equals("/complain")) {	
			System.out.println("In controller");
			try {
				String folderName = "Images";
	            String uploadPath = "D:\\core_mini_project\\Grievance\\src\\main\\webapp\\"+ folderName ;
	            System.out.println(uploadPath);
	            File dir = new File(uploadPath);
	            if (!dir.exists()) {
	                dir.mkdirs();
	            }
	            Part filePart = request.getPart("file");
	            String fullPath = filePart.getSubmittedFileName();
	            String fileName = fullPath.substring(fullPath.lastIndexOf("\\")+1);
//	            String filepath = folderName + File.separator + fileName;
	            uploadPath = uploadPath + File.separator + fileName; 
//	            Timestamp added_date = new Timestamp(System.currentTimeMillis());
	            System.out.println("fileName: " + fileName);
	            System.out.println("Path: " + uploadPath);
	          
	            InputStream is = filePart.getInputStream();
	            Files.copy(is, Paths.get(uploadPath), StandardCopyOption.REPLACE_EXISTING);
				Complain citiz = new Complain();
				citiz.setDeptId("Road");
				citiz.setDescription(request.getParameter("desc"));
				citiz.setFile(uploadPath);
				citiz.setStatus("Active");
				System.out.println("controller");
				complainSer.addComplain(citiz);
				//			response.sendRedirect("listuser");	
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
