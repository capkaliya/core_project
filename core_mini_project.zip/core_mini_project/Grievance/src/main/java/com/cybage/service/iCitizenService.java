package com.cybage.service;

import com.cybage.model.Complain;

public interface iCitizenService {
	public int addComplain(Complain comp) throws Exception ;
		
	

}
