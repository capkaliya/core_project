package com.cybage.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import com.cybage.model.Complain;

public class CitizenDaoImpl {

	public int addComplain(Complain comp) throws Exception {
		String sql = "insert into complaintable values(?, ?, ?, ?, ?, ?, ?, ?)";
		Connection connection = DbUtil.getConnection();
		PreparedStatement ps = connection.prepareStatement(sql);

		ps.setString(1, comp.getCompId());
		ps.setString(2, "Road");
		ps.setString(3, "NO DATA");
		ps.setString(4, comp.getDescription());
		ps.setString(5, comp.getStatus());
		ps.setString(6, "REMARK");
		ps.setString(7, comp.getFile());
		ps.setDate(8, java.sql.Date.valueOf(comp.getDate()));
		System.out.println("value added");
		return ps.executeUpdate();
	}
}
